/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.pro1;

import static com.mycompany.pro1.newclass1.sf;
import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import java.util.Scanner; 
/**
 *
 * @author st28_1018
 */
public class newclass1 {
    
    static SessionFactory sf = null;
    public static void main(String[] args){
        
       
        Configuration cg = new Configuration();
        cg.configure();
        
        sf = cg.buildSessionFactory();
        
        //delete(8790);
        insert();
        
       // Session s = sf.openSession();
        
        
        
        HashSet<Orders> sh = new HashSet<>();
        /*
        Agents a = new Agents("vfr", "sdf" , "sdfv", "dsvf", "dsv", sh);
        Orders o = new Orders(8790,a, new BigDecimal(3243));
        sh.add(o);        
        s.beginTransaction();
         s.save(a);
   
       s.save(o);
       
        */
        
        
        // s.getTransaction().commit();
        
       // s.close();
        sf.close();
       
    }
   
    
    
    
    
    public static void delete( int agentid ){
     
    
        Session session = sf.openSession();
                //
                //Query query=session.createQuery("update Customer c set email=:email where c.customerId=:id");
                // or 
                session.beginTransaction();
                Query query=session.createQuery("delete from Orders where orderNum=:id");
                query.setInteger("id", agentid);
                int modifications=query.executeUpdate();
                session.getTransaction().commit();
                session.close();
    }
    

    public static void insert( ){
        Scanner myObj = new Scanner(System.in);  // Create a Scanner object
    System.out.println("Enter username");

    String userName = myObj.nextLine();  // Read user input
    System.out.println("Username is: " + userName);  // Output user input 
     
     Session session = sf.openSession();
     session.beginTransaction();
        Set<Orders> s = new HashSet<>();
        
       
        Agents a1 = new Agents("A019" ,"Rama" ,"Bang","077258655763","canada", s );
        
        Orders o = new Orders( 123,a1,new BigDecimal(3243));
        s.add(o);
        
        session.save(a1);
        session.save(o);
      
          session.getTransaction().commit();
        session.close();
        sf.close();      
    
        
    }
}